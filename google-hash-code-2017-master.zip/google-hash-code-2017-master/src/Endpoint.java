/**
 * Endpoint
 *
 * Google HashCode 2017
 * Created by Marcel Eschmann, Cedric Seger and Simone Stefani on 23/02/2017.
 */

public class Endpoint {
    public int latency;
    public int [] cachesId;
    public int [] cachesLatency;
}
